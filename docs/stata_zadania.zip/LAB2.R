# Zadanie 1 ---------------------------------------------------------------
l = list(c("Magda", "Biada�a"), pi, sqrt, seq(0.02:1, by=0.02))
l[c(1,3)] = NULL
lapply(l,gamma)

# Zadanie 2 ---------------------------------------------------------------
m = matrix(c(1,5,3,2,0,5,1,2,1),nrow=3, ncol=3, byrow=T)
install.packages("Matrix", dependencies = TRUE)
library("Matrix")
rankMatrix(m)
det(m)
n = solve(m)
eigen(m)
rowSums(m)
rowMeans(m)
colSums(m)
colMeans(m)
m %*% n

# Zadanie 3 ---------------------------------------------------------------
v = (1:100)^2
v_factor = factor(v%%10)
table(v_factor)

# Zadanie 4 ---------------------------------------------------------------
x=(1:5)
y=(1:5)
wyniki = outer(x, y, FUN=function(x,y) paste(x,'*', y,'=', x*y))
wyniki

# Zadanie 5 ---------------------------------------------------------------
dane = read.csv("C:/Users/Magda/Desktop/infa/statystyka/dane1.csv", header=T, sep=';')
View(dane)
dane[seq(2,nrow(dane),by=2),]
dane[dane$Wiek > 50 & dane$Wezly.chlonne == 1, ]

# Zadanie 6 ---------------------------------------------------------------
ramka = data.frame(NY_F = c(32, 33, 41, 52, 62, 72, 77, 75, 68, 58, 47, 35))
ramka$NY_C = round((ramka$NY_F-32)*(5/9), 2)
colnames(ramka) = c("NY_Fahrenheit","NY_Celsiusz")
ramka$NY_Fahrenheit = NULL
save(ramka, file="C:/Users/Magda/Desktop/infa/statystyka/NY_temp")
