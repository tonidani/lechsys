# Zadanie 1 ---------------------------------------------------------------
x = c(862, 870, 876, 866, 871, 865, 861, 873, 871, 872)
shapiro.test(x)
# rozk�ad normalny
qqnorm(x)
qqline(x)
mean(x)
?t.test
t.test(x, alternative = "less", mu = 870)
# nie mam podstaw do odrzucenia hipotezy zerowej
# �rednia istotnie nie r�ni si� od 870

# Zadanie 2 ---------------------------------------------------------------
x = c(0.782,0.785,0.756,0.785,0.774,0.766)
y = c(0.761,0.752,0.758,0.773,0.773,0.77,0.744,0.762,0.735,0.774)
boxplot(x,y)
shapiro.test(x)
qqnorm(x)
qqline(x)
shapiro.test(y)
qqnorm(y)
qqline(y)
#obie zmienne maj� rozk��d normalny
var(x)
var(y)
var.test(x, y, alternative = "less")
# nie mam podstaw do odrzucenia hipotezy zerowej
# zak�adam jednorodno�� wariancji
mean(x)
mean(y)
t.test(x, y, alternative = "greater", var.equal=T)
# odrzucam hipotez� zerow�
# proszki r�ni� si� od siebie

# Zadanie 3 ---------------------------------------------------------------
przed = c(84, 87, 87, 90, 90, 90, 90, 93, 93, 96)
po = c(89, 92, 98, 95, 95, 92, 95, 92, 98, 101)
boxplot(przed, po)
shapiro.test(przed)
qqnorm(przed)
qqline(przed)
shapiro.test(po)
qqnorm(po)
qqline(po)
#obie zmienne maj� rozk�ad normalny
mean(przed)
mean(po)
t.test(przed, po, alternative = 'less', paired = TRUE)
# odrzucam hipotez� zerow�
# film poprawi� stosunek do szk� publicznych

# Zadanie 4 ---------------------------------------------------------------
m = c(171, 176, 179, 189, 176, 182, 173, 179, 184, 186, 189, 167, 177)
k = c(161, 162, 163, 162, 166, 164, 168, 165, 168, 157, 161, 172)
boxplot(m,k)
shapiro.test(m)
qqnorm(m)
qqline(m)
shapiro.test(k)
qqnorm(k)
qqline(k)
#obie zmienne maj� rozk�ad normalny
var(m)
var(k)
var.test(m, k, alternative = "greater")
# odrzucam hipotez� zerow�
# wariancje nie s� jednorodne
mean(m)
mean(k)
t.test(m, k, alternative = "greater", var.equal=F)
# odrzucam hipotez� zerow�
# m�czy�ni i kobiety r�ni� si� od siebie wzrostem

# Zadanie 5 ---------------------------------------------------------------
w_test <- function(x, lambda_zero, alternative = c('two.sided', 'less', 'greater')) {
  statistic <- 2 * length(x) * lambda_zero * mean(x)
  d <- 2 * length(x)
  alternative <- match.arg(alternative)
  p_value <-  pchisq(statistic, d)
  p_value <-  switch(alternative, 
                     'two.sided' = 2 * min(p_value, 1 - p_value), 
                     'greater' = p_value, 
                     'less' = 1 - p_value)
  names(statistic) <- 'T'
  names(d) <- 'num df'
  result <- list(statistic = statistic, 
                 parameter = d, 
                 p.value = p_value, 
                 alternative = alternative, 
                 method = 'Test chi-kwadrat w modelu wyk�adniczym', 
                 data.name = deparse(substitute(x)))
  class(result) <- 'htest'
  return(result)
}

awarie <- read.table("http://ls.home.amu.edu.pl/data_sets/awarie.txt")
1 / mean(awarie$V1)
w_test(awarie$V1, 0.001, 'less')
