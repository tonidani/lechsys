# Zadanie 1 ---------------------------------------------------------------
load("C:/Users/Magda/Desktop/infa/statystyka/Centrala.RData")
View(Centrala)
attach(Centrala)
library(EnvStats)
p_est = mean(Liczba)
epois(Liczba, ci=T, method='mle/mme/mvue', ci.method = "exact")$interval$limits
epois(Liczba, ci=T, method='mle/mme/mvue', ci.method = "pearson.hartley.approx")$interval$limits
epois(Liczba, ci=T, method='mle/mme/mvue', ci.method = "normal.approx")$interval$limits
epois(Liczba, ci=T)$interval$limits

# Zadanie 2 ---------------------------------------------------------------
awarie = read.table("C:/Users/Magda/Desktop/infa/statystyka/awarie.txt", header=F)
library(dplyr)
awarie = dplyr::rename(awarie, Czas = V1)
View(awarie)
attach(awarie)
lambda_limits = eexp(Czas,ci=T)$interval$limits

#dlaczego tak?
rev(1 / lambda_limits)
rev(1 / lambda_limits^2)

# Zadanie 3 ---------------------------------------------------------------
#1
median_cint <- function(x, conf_level = 0.95) {
  a = 1 - conf_level
  n = length(x)
  m = mean(x^2)
  L = sqrt(log(2) * m * (1 - qnorm(1-a/2)/sqrt(n)))
  R = sqrt(log(2) * m * (1 + qnorm(1-a/2)/sqrt(n)))
  return(list(title = "mediana", est = sqrt(log(2) * m), l = L, r = R, conf_level = conf_level))
}

#2
wind = c(0.9, 6.2, 2.1, 4.1, 7.3, 1.0, 4.6, 6.4,
         3.8, 5.0, 2.7, 9.2, 5.9,
         7.4, 3.0, 4.9, 8.2, 5.0, 1.2,
         10.1, 12.2, 2.8, 5.9, 8.2, 0.5)

print.confint <- function(x) {
  cat(x$conf_level * 100, "percent confidence interval:", "\n")
  cat(x$l, " ", x$r, "\n")
}

summary.confint <- function(x) {
  cat("\n", "Confidence interval of", x$title, "\n", "\n")
  cat(x$conf_level * 100, "percent confidence interval:", "\n")
  cat(x$l, " ", x$r, "\n")
  cat("sample estimate", "\n")
  cat(x$est, "\n")
}

z = median_cint(wind)
print.confint(z)
summary.confint(z)

# Zadanie 4 ---------------------------------------------------------------
conf_int <- function(x, conf_level = 0.95) {
  c(mean(x) - sd(x) * qt(1 - (1 - conf_level) / 2, length(x) - 1) / sqrt(length(x)), 
    mean(x) + sd(x) * qt(1 - (1 - conf_level) / 2, length(x) - 1) / sqrt(length(x)))
}

nr <- 1000
n <- 100
cat(paste("n = ", n, sep = ""), "\n")

temp <- numeric(nr)
set.seed(1234)
for (i_nr in seq_len(nr)) {
  x <- rnorm(n, mu, sigma)
  temp_int <- conf_int(x)
  temp[i_nr] <- ((temp_int[1] < 1) & (1 < temp_int[2]))
}
mean(temp)

temp <- numeric(nr)
set.seed(1234)
for (i_nr in seq_len(nr)) {
  x <- rchisq(n, 3)
  temp_int <- conf_int(x)
  temp[i_nr] <- ((temp_int[1] < 3) & (3 < temp_int[2]))
}
mean(temp)

temp <- numeric(nr)
set.seed(1234)
for (i_nr in seq_len(nr)) {
  x <- rexp(n, 3)
  temp_int <- conf_int(x)
  temp[i_nr] <- ((temp_int[1] < 1/3) & (1/3 < temp_int[2]))
}
mean(temp)
