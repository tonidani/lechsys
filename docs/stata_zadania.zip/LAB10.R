auto <- read.csv("C:/Users/Magda/Desktop/infa/statystyka/Automobile.csv", sep = ",", header = T, na.strings = "?")
nrow(auto)

# Zadanie1.1 --------------------------------------------------------------
auto <- na.omit(auto)
nrow(auto)
ncol(auto)

# Zadanie1.2 --------------------------------------------------------------
head(auto)
?pairs

model_1 <- lm(formula = price ~ horsepower + city.mpg + peak.rpm + curb.weight + num.of.doors, data = auto)
model_1
coef(model_1)
confint(model_1)
summary(model_1)
fitted(model_1)
residuals(model_1)


# Zadanie1.3 i 1.4 --------------------------------------------------------------
model_none <- lm(price ~ 1, data = auto)

# regresja krokowa AIC backward
step(model_1)
# regresja krokowa AIC forward
step(model_none, direction = "forward", scope = formula(model_1))
# regresja krokowa BIC backward
step(model_1, k = log(nrow(auto)))
# regresja krokowa BIC forward
step(model_none, direction = "forward", scope = formula(model_1), k = log(nrow(auto)))
#wszystkie i tak wyplu�y ten sam model


# Zadanie1.5 --------------------------------------------------------------
install.packages("Hmisc", dependencies = TRUE)
library(Hmisc)

x = impute(auto, fun = 'mean')
summary(x)
# Zadanie1.6 --------------------------------------------------------------

