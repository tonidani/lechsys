# Zadanie 1 ---------------------------------------------------------------
x = 1:5
i = 1
wynik = 1

while (i<=5) {
  wynik = wynik * x[i]
  print(wynik)
  i = i + 1
}

repeat {
  wynik = wynik * x[i]
  print(wynik)
  i = i + 1
  if (i >= 6) break
}

for (i in x) wynik = wynik * i
print(wynik)

# Zadanie 2 ---------------------------------------------------------------
counter = 0
for (i in (1:100)){
  for (j in (i:100)){
    n = choose(j,i)
    if (n > 1000000){
        counter = counter + 1
    }
  }
}
print(counter)

# Zadanie 3 ---------------------------------------------------------------
pali = function(x) {
  b = (rev(x))
  if (all(b==x)) print("palindrom")
  else print("nie")
}
w = c(2,3,6,3,2)
pali(w)

# Zadanie 4 ---------------------------------------------------------------
radians = function(d) {
  return(d*pi/180)
}

katy = c(0,30,45,60,90)
ramka = data.frame(sin=sin(radians(katy)), cos=cos(radians(katy)), tg=tan(radians(katy)), ctg=1/tan(radians(katy)))
View(ramka)

# Zadanie 5 ---------------------------------------------------------------
extreme_3 = function(x) {
  if (length(x)<6) warning("za kr�tki argument")
  else {
    sorted = sort(x)
    return(c(head(sorted,3),tail(sorted,3)))
  }
}
x = c(2,1,3,7,4)
extreme_3(x)
