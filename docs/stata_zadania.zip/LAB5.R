# Zadanie 1 ---------------------------------------------------------------

# Zadanie 2 ---------------------------------------------------------------
#1
load("C:/Users/Magda/Desktop/infa/statystyka/Centrala.RData")
View(Centrala)
# rozk�ad empiryczny
data.frame(cbind(liczebnosc = table(Centrala$Liczba),
                 procent = prop.table(table(Centrala$Liczba))))
barplot(table(Centrala),
       xlab = "Liczba zg�osze�",
       ylab = "Liczebno��",
       main = "Rozk�ad empiryczny liczby zg�osze�",
       col = c("black","red","green","blue","lightblue","purple"))
#2
# warto�� lambda (estymator) = �rednia rozk�adu empirycznego
p_est = mean(Centrala$Liczba)
# rozk�ad teoretyczny
barplot(dpois(x = 0:5, lambda = p_est), names.arg = 0:5,
        xlab = "k", ylab = "P(X=k)", main = "Funkcja prawdopodobie�stwa")

#3
# rozk�ad teoretyczny 
probs = dpois(sort(unique(Centrala$Liczba)), lambda = p_est)             
sum(probs)
# tabela z warto�ciami dla rozk�adu empirycznego i teoretycznego
counts = matrix(c(prop.table(table(Centrala$Liczba)), probs), nrow=2, byrow=T)
rownames(counts) <- c("empiryczny", "teoretyczny")
colnames(counts) <- sort(unique(Centrala$Liczba))
counts
# wykres z tabeli
barplot(counts, 
        xlab = "Liczba zg�osze�", ylab = "Prawdopodobie�stwo",
        main = "Rozk�ady empiryczny i teoretyczny liczby zg�osze�",
        col = c("red", "blue"), legend = rownames(counts), beside = T)
#4
qqplot(rpois(length(Centrala$Liczba), lambda = p_est), Centrala$Liczba)
qqline(Centrala$Liczba, distribution = function(probs) { qpois(probs, lambda = p_est) })
#lub
install.packages("EnvStats", dependencies = T)
library(EnvStats)
EnvStats::qqPlot(Centrala$Liczba,
                 distribution = "pois",
                 param.list = list(lambda = p_est),
                 add.line = TRUE)

# empirycznie
mean(Centrala$Liczba < 4)
# teoretycznie
# P(X < 4) = P(X <= 3) bo to rozk�ad dyskretny
ppois(3, lambda=p_est)

# Zadanie 3 ---------------------------------------------------------------

# Zadanie 4 ---------------------------------------------------------------
#1
wind = c(0.9, 6.2, 2.1, 4.1, 7.3, 1.0, 4.6, 6.4,
         3.8, 5.0, 2.7, 9.2, 5.9,
         7.4, 3.0, 4.9, 8.2, 5.0, 1.2,
         10.1, 12.2, 2.8, 5.9, 8.2, 0.5
)
install.packages("VGAM", dependencies = T)
library(VGAM)
#2
enw = sum((wind)^2)/length(wind)
sqrt(enw / 2)
#3
hist(wind, xlab = "�rednia szybko�� wiartu", main = "Rozk�ad empiryczny �redniej szybko�ci wiatru", col='green', probability=TRUE)
lines(density(wind), col = "red", lwd = 2)
curve(VGAM::drayleigh(x, sqrt(enw/2)),
      add = TRUE, col = "blue", lwd = 2)

legend(x = 9, y = 0.12, legend = c("empiryczny", "teoretyczny"), col = c("red", "blue"), lwd = 2)
#4
n = length(wind)
qqplot(VGAM::rrayleigh(length(wind), sqrt(enw/2)), wind)
qqline(wind, distribution = function(probs) { VGAM::qrayleigh(probs, scale=sqrt(enw/2)) })
#5
#Tak
#6
mean(wind >= 4 & wind <= 8)
#P(4 <= X <= 8) = P(X <= 8) - P(X <= 4) 
VGAM::prayleigh(8, sqrt(enw/2)) - VGAM::prayleigh(4, sqrt(enw/2))
