
# Zadanie 1 ---------------------------------------------------------------
?data.frame
Rok = c(1995,	1996,	1997,	1998,	1999,	2000,	2001, 2002)
Przypadki = c(39.7,	38.2,	34.7,	33.1,	30.1,	28.4,	26.3,	24.7)
Gruz = data.frame(Rok, Przypadki)
View(Gruz)

#wykres rozrzutu
plot(Gruz, main = "Wykres rozrzutu", , pch = 16)

#model
model <- lm(Przypadki ~ Rok, data = Gruz)
model

#rysuj model
plot(Gruz, main = "Wykres rozrzutu", , pch = 16)
abline(model, col = "red", lwd = 2)

#przedzia�y ufno�ci modelu
confint(model)
summary(model)

#warto�ci dopasowane przez model i reszty
fitted(model)
residuals(model)

#przedzia�y ufno�ci rysowanie
temp_rok <- data.frame(Rok = seq(min(Gruz$Rok) - 1, 
                                             max(Gruz$Rok) + 1, 
                                             length = 100))
temp_rok
pred <- stats::predict(model, temp_rok, interval = "prediction")
plot(Gruz, main = "Wykres rozrzutu", pch = 16)
abline(model, col = "red", lwd = 2)
lines(temp_rok$Rok, pred[, 2], lty = 2, col = "red")
lines(temp_rok$Rok, pred[, 3], lty = 2, col = "red")

#predykcja

new_rok <- data.frame(rok = 2003:2007)
(pred_2003_2007 <- predict(model, new_rok, interval = 'prediction'))
pred_2003_2007
plot(Gruz, main = "Wykres rozrzutu z predykcj� na lata 2003-2007", pch = 16,
     xlim = c(1995, 2007), ylim = c(10, 40))
abline(model, col = "red", lwd = 2)
points(2003:2007, pred_2003_2007[, 1], col = "blue", pch = 16)
temp_rok <- data.frame(rok = seq(1994, 2008, length = 100))
pred <- predict(model, temp_rok, interval = "prediction")
lines(temp_rok$rok, pred[, 2], lty = 2, col = "red")
lines(temp_rok$rok, pred[, 3], lty = 2, col = "red")

#nowe_przypadki <- data.frame(Rok = c(2003:2007))
#predictions <- stats::predict(model, nowe_przypadki, interval = 'prediction')
#plot(c(Rok,c(2003:2007)), c(Przypadki, predictions[1:5]), main = "Wykres rozrzutu", pch = 16)

# Zadanie 2 ---------------------------------------------------------------
load("C:/Users/Magda/Desktop/infa/statystyka/braking.RData")
View(braking)
plot(braking, main = "Wykres rozrzutu", pch = 16)

#wycinanie obserwacji odstaj�cej
idx = braking$distance < 150
braking_clean = braking[idx,]
View(braking_clean)
plot(braking_clean, main = "Wykres rozrzutu", pch = 16)

#modele
model <- lm(distance ~ speed, data = braking)
plot(braking, main = "Wykres rozrzutu", pch = 16)
abline(model, col = "red", lwd = 2)
coef(model)
confint(model)
summary(model)
fitted(model)
residuals(model)

model_clean <- lm(distance ~ speed, data = braking_clean)
plot(braking_clean, main = "Wykres rozrzutu", pch = 16)
abline(model_clean, col = "red", lwd = 2)
coef(model_clean)
confint(model_clean)
summary(model_clean)
fitted(model_clean)
residuals(model_clean)

# przedzia�y ufno�ci dla predykcji
# pierwszy model
temp_speed <- data.frame(speed = seq(min(braking$speed) - 2, 
                                             max(braking$speed) + 2, 
                                             length = 100))
temp_speed
pred <- stats::predict(model, temp_speed, interval = "prediction")
plot(braking, main = "Wykres rozrzutu", pch = 16)
abline(model, col = "red", lwd = 2)
lines(temp_speed$speed, pred[, 2], lty = 2, col = "red")
lines(temp_speed$speed, pred[, 3], lty = 2, col = "red")

#drugi model
temp_speed2 <- data.frame(speed = seq(min(braking_clean$speed) - 2, 
                                           max(braking_clean$speed) + 2, 
                                           length = 100))
temp_speed2
pred2 <- stats::predict(model_clean, temp_speed2, interval = "prediction")
plot(braking_clean, main = "Wykres rozrzutu", pch = 16)
abline(model_clean, col = "red", lwd = 2)
lines(temp_speed2$speed, pred2[, 2], lty = 2, col = "red")
lines(temp_speed2$speed, pred2[, 3], lty = 2, col = "red")


#predykcja
predkosci = c(30:50)
new_speed <- data.frame(speed = predkosci)

predictions <- stats::predict(model, new_speed, interval = 'prediction')
predictions

predictions_clean <- stats::predict(model_clean, new_speed, interval = 'prediction')
predictions_clean

#du�a r�nica w modelach je�li chodzi o przewidywanie nowej warto�ci 
#model w kt�rym usuni�to odstaj�c� obserwacj� przewiduje dok�adniej
