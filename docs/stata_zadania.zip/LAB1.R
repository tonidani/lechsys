# ctrl+shift+R podzia� kodu na sekcje
# ctrl+shift+C zakomentowanie zaznaczonej cz�ci kodu
# ?mean lub help(mean) - wy�wietla info o funkcj

# Zadanie2 ----------------------------------------------------------------
?rep
x = c(rep(TRUE, 3), rep(FALSE, 4), rep(TRUE, 2), rep(FALSE, 5))
as.numeric(x)

# Zadanie3 ----------------------------------------------------------------
x = c((1:20), rep(0,10), seq(2,40,by = 2))
c(x,rev(x))

# Zadanie4 ----------------------------------------------------------------
x = c(letters)
x[seq(5,25,by=5)]

# Zadanie5 ----------------------------------------------------------------
x = (1:1000)
x[seq(2,1000,by=2)] = rep(1, 500)/seq(2,1000,by=2)
x

# Zadanie6 ----------------------------------------------------------------
x = c(6,3,4,5,2,3)
x[order(x, decreasing=TRUE)]

# Zadanie7 ----------------------------------------------------------------
x = c(-1.876, -1.123, -0.123, 0, 0.123, 1.123, 1.876)
sign(x)
round(x, digits = 2)
floor(x)

# Zadanie8 ----------------------------------------------------------------
t1 = Sys.time()
sqrt(1:100000000)
Sys.time()-t1
# time difference of 2.120699 secs

t2 = Sys.time()
(1:100000000)^(1/2)
Sys.time()-t2
# time difference of 5.611537 secs

# Zadanie9 ----------------------------------------------------------------
install.packages("schoolmath", dependencies = TRUE)
library("schoolmath")

p = primlist[primlist < 1000]
l = length(p)
p[-(1:l-1)]

pr = primlist[primlist > 100 & primlist < 500]
length(pr)

# Zadanie10 ----------------------------------------------------------------
v1 = c("a","b")
v2 = c(1,2,3)
a = paste(rep(v1[1], 3),v2, sep="")
b = paste(rep(v1[2], 3),v2, sep="")
c(a,b)

# Zadanie11 ----------------------------------------------------------------
l = c("X","Y","Z")
paste((1:30),rep(l,10), sep=".")

# Zadanie12 ----------------------------------------------------------------
l = c("a","b","c","d","e")
o = sample(l, 100, replace=TRUE)

install.packages("car", dependencies = TRUE)
library("car")

recode(o, "c('a','b') = 1; c('c','d') = 2; else=3")
