
# Zadanie 1 ---------------------------------------------------------------
dane <- read.table("http://ls.home.amu.edu.pl/data_sets/kontekst.txt")
colnames(dane) <- c("number", "context")
View(dane)
dane$context <- as.factor(dane$context)
summary(dane)

#1
aggregate(dane$number, 
          list(CONTEXT = dane$context), 
          FUN = mean)
boxplot(number ~ context, data = dane)

#2 anova
summary(aov(number ~ context, data = dane))

#3 za�o�enia
shapiro.test(lm(number ~ context, data = dane)$residuals)
qqnorm(dane$number)
qqline(dane$number)
# nie ma podstaw do odrzucenia hipotezy zerowej
# dane maj� rozk�ad normalny
bartlett.test(number ~ context, data = dane)
fligner.test(number ~ context, data = dane)
library(car)
leveneTest(number ~ context, data = dane)
leveneTest(number ~ context, data = dane, center = 'mean')
# nie ma podstaw do odrzucenia hipotezy zerowej
# wariancje s� jednorodne


#4 testy post hoc
attach(dane)
pairwise.t.test(number, context, data = dane)
#r�ni� si�: Different i Photo, Photo i Placebo, Same i Placebo

model_aov <- aov(number ~ context, data = dane)
TukeyHSD(model_aov)
plot(TukeyHSD(model_aov))
# te same r�nice jak wy�ej

#tu fajny podzia� na grupy
install.packages("agricolae", dependencies = TRUE)
library(agricolae)
HSD.test(model_aov, "context", console = TRUE)
# te same r�nice jak wy�ej

SNK.test(model_aov, "context", console = TRUE)
# tu r�nica mi�dzy Photo, Same i Imagery a Different i Placebo

LSD.test(model_aov, "context", p.adj = "holm", console = TRUE)
# tak jak w HSD

scheffe.test(model_aov, "context", console = TRUE)
# r�nica tylko pomi�dzy Photo a Placebo


#5 kontrasty
C1 <- c(-3, 2, 2, -3, 2)
C2 <- c(0, -1, -1, 0, 2)
C3 <- c(0, 1, -1, 0, 0)
C4 <- c(1, 0, 0, -1, 0)
con <- cbind(C1, C2, C3, C4) 
contrasts(dane$context) <- con
model_aov_2 <- aov(number ~ context, data = dane)
summary(model_aov_2, split = list(context = list('C1' = 1, 'C2' = 2, 'C3' = 3, 'C4' = 4)))
# pierwszy i drugi kontrast istotny, pozosta�e nie



# Zadanie 2 ---------------------------------------------------------------
#1
eysenck = read.table("C:/Users/Magda/Desktop/infa/statystyka/Eysenck.txt", header=T)
eysenck$Nr <- NULL
View(eysenck)

#2
eysenck$Instrukcja <- as.factor(eysenck$Instrukcja)
summary(eysenck)
aggregate(eysenck$Wynik, 
          list(CONTEXT = eysenck$Instrukcja), 
          FUN = mean)
boxplot(Wynik ~ Instrukcja, data = eysenck)


#3 anova
summary(aov(Wynik ~ Instrukcja, data = eysenck))


#4 za�o�enia
shapiro.test(lm(Wynik ~ Instrukcja, data = eysenck)$residuals)
qqnorm(eysenck$Wynik)
qqline(eysenck$Wynik)
# nie ma podstaw do odrzucenia hipotezy zerowej
# dane maj� rozk�ad normalny
bartlett.test(Wynik ~ Instrukcja, data = eysenck)
fligner.test(Wynik ~ Instrukcja, data = eysenck)
library(car)
leveneTest(Wynik ~ Instrukcja, data = eysenck)
leveneTest(Wynik ~ Instrukcja, data = eysenck, center = 'mean')
# nie ma podstaw do odrzucenia hipotezy zerowej
# wariancje s� jednorodne


#5 testy post hoc
attach(eysenck)
pairwise.t.test(Wynik, Instrukcja, data = eysenck)
# nie r�ni� si�: Wyobra�nia i Kontrola, Wyobra�nia i Przymiotnik, Rymowanie i Liczenie

model_aov <- aov(Wynik ~ Instrukcja, data = eysenck)
TukeyHSD(model_aov)
plot(TukeyHSD(model_aov))
# te same r�nice jak wy�ej

#tu fajny podzia� na grupy
library(agricolae)
?HSD.test
HSD.test(model_aov, "Instrukcja", console = T)
# te same r�nice jak wy�ej

SNK.test(model_aov, "Instrukcja", console = TRUE)
# tu brak r�nic mi�dzy Wyobra�nia i Kontrola, Rymowanie i Liczenie

LSD.test(model_aov, "Instrukcja", p.adj = "holm", console = TRUE)
# tak jak w HSD

scheffe.test(model_aov, "Instrukcja", console = TRUE)
# tak samo jak w HSD


#6 kontrasty
C1 <- c(0, 1, -1, 1, -1)
C2 <- c(4, -1, -1, -1, -1)
C3 <- c(0, 1, 0, -1, 0)
C4 <- c(0, 0, 1, 0, -1)
con <- cbind(C1, C2, C3, C4) 
contrasts(eysenck$Instrukcja) <- con
model_aov_2 <- aov(Wynik ~ Instrukcja, data = eysenck)
summary(model_aov_2, split = list(Instrukcja = list('C1' = 1, 'C2' = 2, 'C3' = 3, 'C4' = 4)))
# tylko 3 kontrast nieistotny