# Zadanie 1 ---------------------------------------------------------------
#1
ankieta = read.table("C:/Users/Magda/Desktop/infa/statystyka/ankieta.txt", header=T)
#2
data.frame(cbind(liczebnosc = table(ankieta[,3]),
                 procent = prop.table(table(ankieta[,3]))))
#3
podst = ankieta[ankieta[,2] == "p",]
data.frame(cbind(liczebnosc = table(podst[,3]),
                 procent = prop.table(table(podst[,3]))))

#4
barplot(table(ankieta[,3]),
        xlab = "Odpowiedzi", ylab = "Liczebno��",
        main = "Rozk�ad empiryczny zmiennej wynik")

barplot(prop.table(table(ankieta[,3])),
        xlab = "Odpowiedzi", ylab = "Liczebno��",
        main = "Rozk�ad empiryczny zmiennej wynik")

pie(table(ankieta[,3]))
#5
?barplot
kobiety = table(ankieta[ankieta[,1]=="k",3])
mezczyzni = table(ankieta[ankieta[,1]=="m",3])
kobiety
mezczyzni

barplot(c(kobiety, mezczyzni), beside=T)
par(mfrow=c(1,1))
data=df or list
names.arg = c("k","m"),

# Zadanie 2 ---------------------------------------------------------------
#1
load("C:/Users/Magda/Desktop/infa/statystyka/Centrala.RData")
lub
load(url("http://ls.home.amu.edu.pl/data_sets/Centrala.RData"))
View(Centrala)
#2
data.frame(cbind(liczebnosc = table(Centrala$Liczba),
                 procent = prop.table(table(Centrala$Liczba))))
#3
barplot(table(Centrala),
     xlab = "Liczba zg�osze�",
     ylab = "Liczebno��",
     main = "Rozk�ad empiryczny liczby zg�osze�",
     col = c("black","red","green","blue","lightblue","purple"))
pie(table(Centrala))
#4
mean(Centrala$Liczba)
median(Centrala$Liczba)
sd(Centrala$Liczba)
sd(Centrala$Liczba)/mean(Centrala$Liczba)*100

# Zadanie 3 ---------------------------------------------------------------
#1
wind = c(0.9, 6.2, 2.1, 4.1, 7.3, 1.0, 4.6, 6.4,
         3.8, 5.0, 2.7, 9.2, 5.9,
         7.4, 3.0, 4.9, 8.2, 5.0, 1.2,
         10.1, 12.2, 2.8, 5.9, 8.2, 0.5
)
wind
data.frame(cbind(liczebnosc = table(cut(wind, breaks = seq(0, 14, 2))),
                 procent = prop.table(table(cut(wind, breaks = seq(0, 14, 2))))))
#2
hist(wind, xlab = "�rednia szybko�� wiartu", main = "Rozk�ad empiryczny �redniej szybko�ci wiatru")
rug(jitter(wind))

hist(wind, xlab = "�rednia szybko�� wiartu",
     main = "Rozk�ad empiryczny �redniej szybko�ci wiatru",
     probability = T,
     col = "lightblue")
lines(density(wind), col = "green", lwd = 2)

boxplot(wind, ylab = "�rednia szybko�� wiartu", main = "Rozk�ad empiryczny �redniej szybko�ci wiatru")
#4
mean(wind)
median(wind)
sd(wind)
sd(wind)/mean(wind)*100
install.packages("e1071", dependencies = T)
library(e1071)
skewness(wind)
kurtosis(wind)

# Zadanie 4 ---------------------------------------------------------------
wspolczynnik_zmiennosci = function(x, na.rm=F) {
        if(!is.numeric(x)) stop("argument nie jest liczb�")
        else {
                return(sd(x, na.rm=na.rm)/mean(x, na.rm=na.rm)*100)
        }
}
wspolczynnik_zmiennosci(c("x","y"))
